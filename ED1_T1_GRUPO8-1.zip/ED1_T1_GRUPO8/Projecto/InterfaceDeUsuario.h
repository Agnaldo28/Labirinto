#include <windows.h>
#include "Labirinto.h"
#include <string.h>
#include <wincon.h>
#include <conio.h>
typedef struct
{
    COR texto;
    COR fundo;
}CORES;

void menuPrincipal();
void mostraCursor(int mostrar);
void alterarCorDoTextoConsola(COR cor);
void iniciarInterface();
void mensagemDeSucesso(char *string);
int converterParaInteiro(char valorNaoVerificado);

void mensagemDeErro(char string[34]);

void mostrarVoltar();
