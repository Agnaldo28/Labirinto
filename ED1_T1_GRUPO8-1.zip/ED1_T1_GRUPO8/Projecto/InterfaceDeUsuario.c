#include "InterfaceDeUsuario.h"

void menuPrincipal()
{
    int i, j;
    int subMenus;
    FILE *ficheiro = lerFicheiro("UI.txt");
    Ponto tamanhoDoTexto;
    Ponto tamanhoDoSubMenu;
    fscanf(ficheiro, "%d %d %d %d %d", &tamanhoDoTexto.x, &tamanhoDoTexto.y, &tamanhoDoSubMenu.x, &tamanhoDoSubMenu.y, &subMenus);

    printf("\n");
    for (i = 0; i < tamanhoDoTexto.x; i++)
    {
        for (j = 0; j < tamanhoDoTexto.y ; j++)
        {
            char c;
            fscanf(ficheiro, "%c", &c);

            if(c == '#')
            {
                alterarCorDoTextoConsola(AQUA);
            } else
            {
                alterarCorDoTextoConsola(CINZA);
            }

            printf("%c", c);
        }
    }

    printf("\n\n");
    while (subMenus != 0)
    {
        for (i = 0; i < tamanhoDoSubMenu.x; ++i)
        {
            for (j = 0; j < 17; ++j) {
                printf(" ");
            }
                for (j = 0; j < tamanhoDoSubMenu.y; ++j)
                {

                    char c;
                    fscanf(ficheiro, "%c", &c);
                    if(c == '\n' && j == 0)
                    {
                        j--;
                        continue;
                    }
                    if (c == '+' || c == '-' || c == '|')
                    {
                        alterarCorDoTextoConsola(CINZA);
                    } else
                    {
                        alterarCorDoTextoConsola(AQUA);
                    }

                    printf("%c", c);
                }
        }

        subMenus--;
    }
    mostraCursor(0);
    fclose(ficheiro);

    
}



void alterarCorDoTextoConsola(COR cor)
{
    HANDLE consola;
    consola = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(consola, cor);
}

void mostraCursor(int mostrar)
{
    HANDLE consola = GetStdHandle(STD_OUTPUT_HANDLE);

    CONSOLE_CURSOR_INFO   infoCursor;

    GetConsoleCursorInfo(consola, &infoCursor);
    infoCursor.bVisible = mostrar;
    SetConsoleCursorInfo(consola, &infoCursor);
}

void iniciarInterface()
{
    Array *caminhosEncontrados;
    int posicaoDoMenorCaminho = 0;
    int numeroDePassosNoMenorCaminho = 0;
    MatrizLabirinto matrizLabirinto = criarLabirinto();
	

    int menuActual = 1, i, calculouCaminhos = 0;
    char valorNaoVerificado;

    while (1)
    {
    	if(caminhosEncontrados->items > 0)
        {
            for(i = 0; i < matrizLabirinto.tamanho.x; i++) {
                int j;
                for (j = 0; j < matrizLabirinto.tamanho.y; ++j) {
                    if(matrizLabirinto.visitado[i][j] == ' ')
                    	matrizLabirinto.visitado[i][j] = 'X';
                }
            }
        }
        if(!calculouCaminhos && (menuActual == 3  || menuActual == 4))
    	{
    		system("cls");
    		
			for(i = 10; i >= 1; i--)
			{
				alterarCorDoTextoConsola(VERMELHO);
				system("cls");
				printf("\n");
				printf("NENHUM CAMINHO CALCULADO PREVIAMENTE!\n");
				alterarCorDoTextoConsola(BRANCO);
    			printf("OS CAMINHOS VAO SER CALCULADOS DE FORMA AUTOMATICA!\n");
    			printf("AGUARDE %d segundos", i);
    			sleep(1);
    			
			}
			menuActual = 2;
		}
		if(caminhosEncontrados->items != 0 && menuActual == 2)
		{
			for(i = 10; i >= 1; i--)
			{
				alterarCorDoTextoConsola(VERMELHO);
				system("cls");
				printf("\n");
				printf("OS CAMINHOS JA FORAM CALCULADOS PREVIAMENTE!\n");
				alterarCorDoTextoConsola(BRANCO);
    			printf("A RETORNAR AO MENU PRINCIPAL!\n");
    			printf("AGUARDE %d segundos", i);
    			sleep(1);
    		}
    		menuActual = 1;
		}
        switch (menuActual)
        {
            case 1:
                system("cls");
                menuPrincipal();
                apresentarMatriz(&matrizLabirinto);
                valorNaoVerificado = getch();
                menuActual = converterParaInteiro(valorNaoVerificado);
                break;
            case 2:
                system("cls");
                caminhosEncontrados = criarArray();
                prepararDados(matrizLabirinto, caminhosEncontrados, &posicaoDoMenorCaminho, &numeroDePassosNoMenorCaminho);
				caminhosEncontrados->vector[posicaoDoMenorCaminho].contemMenorCaminho =0;
				calculouCaminhos = 1;
                system("cls");
                if(caminhosEncontrados->items == 0)
                    mensagemDeErro("NAO FORAM ENCONTRADOS CAMINHOS!");
                else
                {
                    char mensagem[50];
                    sprintf(mensagem, "FORAM ENCONTRADOS %d CAMINHOS", caminhosEncontrados->items);

                    mensagemDeSucesso(mensagem);
                }
                mostrarVoltar();
                valorNaoVerificado = getch();
                menuActual = converterParaInteiro(valorNaoVerificado);
                break;
            case 3:
                system("cls");
                apresentarMatriz(&caminhosEncontrados->vector[posicaoDoMenorCaminho]);
                printf("\nPASSOS ATE A SAIDA %d", numeroDePassosNoMenorCaminho);
                mostrarVoltar();
                valorNaoVerificado = getch();
                menuActual = converterParaInteiro(valorNaoVerificado);
                break;
            case 4:
                system("cls");
                for(i = 0; i < caminhosEncontrados->items; i++)
                    apresentarMatriz(&caminhosEncontrados->vector[i]);
                mostrarVoltar();
                valorNaoVerificado = getch();
                menuActual = converterParaInteiro(valorNaoVerificado);
                break;
            case 5:
                exit(1);

        }
    }
}

int converterParaInteiro(char valorNaoVerificado)
{
    int menu = valorNaoVerificado - '0';

    while (menu < 1 || menu > 5)
    {
        system("cls");
        mensagemDeErro("MENU INVALIDO!");
        mostrarVoltar();
        valorNaoVerificado = getch();
        menu = valorNaoVerificado - '0';
    }
    return menu;

}

void mostrarVoltar()
{
    int i, j;
    int submenus = 5;
    FILE *ficheiro = lerFicheiro("UIVoltar.txt");
    Ponto tamanhoDoTexto;
    fscanf(ficheiro, "%d %d", &tamanhoDoTexto.x, &tamanhoDoTexto.y);

    printf("\n");
    while(submenus) {
        for (i = 0; i < tamanhoDoTexto.x; i++) {
            for (j = 0; j < tamanhoDoTexto.y; j++) {
                char c;
                fscanf(ficheiro, "%c", &c);

                if (c == '+' || c == '-' || c == '|') {
                    alterarCorDoTextoConsola(CINZA);
                } else {
                    alterarCorDoTextoConsola(AQUA);
                }

                printf("%c", c);
            }
        }
        submenus--;
    }

}

void mensagemDeErro(char *string)
{
    int j;
    alterarCorDoTextoConsola(VERMELHO);
    printf("\n");
    for (j = 0; j < 17; ++j)
        printf(" ");
    printf("%s", string);
}

void mensagemDeSucesso(char *string)
{
    int j;
    alterarCorDoTextoConsola(VERDE);
    printf("\n");
    for (j = 0; j < 10; ++j)
        printf(" ");
    printf("%s", string);
}
