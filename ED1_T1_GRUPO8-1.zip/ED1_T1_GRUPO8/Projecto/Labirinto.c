#include"Labirinto.h"
#include<string.h>
#include <limits.h>
#include <unistd.h>

//Cria uma estrutura Labirinto, contendo os dados do labirinto e os blocos que compoêm o labirinto
MatrizLabirinto criarLabirinto()
{
    MatrizLabirinto labirinto;

    //Lê o ficheiro que contem o labirinto
    FILE *ficheiro = lerFicheiro("labirinto.txt");
    //Lê os valores inciais (tamanho, entrada e saida) e armazena na variavel labirinto
    lerDadosInciais(&labirinto, ficheiro);

    //Alloca Memoria para aramazenar os blocos do labirinto
    allocarMatriz(&labirinto);

    //Lê os os blocos ( '*'(asteristicos) e ' ' espaços ) e armazena na struct labirinto
    lerBlocosDoFicheiro(&labirinto,ficheiro);

    return labirinto;
}

/*Lê os valores inciais (tamanho, entrada e saida) e armazena na
 variavel 'labirinto' que vai ser passada por referencia*/
void lerDadosInciais(MatrizLabirinto *labirinto, FILE *ficheiro)
{
    fscanf(ficheiro,"%d %d %d %d %d %d",&labirinto->tamanho.x,&labirinto->tamanho.y,
           &labirinto->entrada.x,&labirinto->entrada.y,
           &labirinto->saida.x,&labirinto->saida.y);
}

/*Lê os os blocos ( '*'(asteristicos) e ' ' espaços ) e armazena na
 variavel 'labirinto' que vai ser passada por referencia*/
void lerBlocosDoFicheiro(MatrizLabirinto *labirinto, FILE *ficheiro)
{
    int i,j;
    for(i = 0; i<labirinto->tamanho.x; i++)
    {
        for(j = 0; j < labirinto->tamanho.y; j++)
        {
            Bloco bloco;
            fscanf(ficheiro,"%c",&bloco.valor);
            if(bloco.valor == '\n')
            {
                j--;
                continue;
            }

            bloco.posicao.x = i;
            bloco.posicao.y = j;
            bloco.foiVisitado = 0;
            labirinto->matriz[i][j] = bloco;
            labirinto->visitado[i][j] = bloco.valor;
        }
    }
}


//Função para ler ficheiro e lidar erro caso não consiga abrir o ficheiro
FILE *lerFicheiro(char *nomeDoFicheiro)
{
    FILE *ficheiro = fopen(nomeDoFicheiro,"r");
    if(ficheiro == NULL)
    {
        printf("ERRO:Ao abrir o ficheiro %s", nomeDoFicheiro);
        system("pause");
        exit(1);
    }   

    return ficheiro;
}


void prepararDados(MatrizLabirinto matriz, Array *caminhosEncontrados, int *posicaoDoMenorCaminho, int *passos)
{
    int i,j;
    int caminhos = 0;
    int *p = &caminhos;
    (*passos) = INT_MAX;

    Fila *fila = criarFila();

    enfilerar(fila, matriz.matriz[matriz.entrada.x][matriz.entrada.y]);

    calcularCaminhosAteASaida(p, matriz, passos, 0, fila, caminhosEncontrados, posicaoDoMenorCaminho);
    printf("%d %d", caminhos, passos);
}

MatrizLabirinto allocarMatriz(MatrizLabirinto *matriz)
{
    int i;
    (*matriz).matriz = malloc((*matriz).tamanho.x * sizeof(Bloco*));
    for (i = 0; i < (*matriz).tamanho.x; i++) {
        (*matriz).matriz[i] = calloc((*matriz).tamanho.y, sizeof(Bloco));
    }

    (*matriz).visitado = malloc((*matriz).tamanho.x * sizeof(char*));
    for (i = 0; i < (*matriz).tamanho.x; i++) {
        (*matriz).visitado[i] = calloc((*matriz).tamanho.y, sizeof(char));
    }

    return (*matriz);
}

void calcularCaminhosAteASaida(int *caminhos, MatrizLabirinto matriz,
                               int *caminhoCurto, int caminhoPercorrido,
                               Fila *fila, Array *array, int *indiceDoCaminhoMaisCurto)
{
    //Remove o primeiro bloco da fila
    Bloco bloco = desenfilerar(fila);

    //Verifica se o ponto(x, y) do bloco corresponde aos da saida
    if(bloco.posicao.x == matriz.saida.x-1 &&
        (bloco.posicao.y == matriz.saida.y-1))
    {
        //Se o percurso percorrido até a saida for menor que o
        //menor percurso conhecido,
        if((*caminhoCurto) > caminhoPercorrido)
        {
            //altera o menor percurso
            (*caminhoCurto) = caminhoPercorrido;
            //Salva o indice do menor percurso para uso posterior
            (*indiceDoCaminhoMaisCurto) = (*caminhos);
        }

        //Salva o percurso percorrido no vector
        inserirNaArray(array, (*caminhos), matriz);
        //Incrementa a qtd de percursos
        (*caminhos)++;
        return;
    }


    //Define o bloco actual como visitado
    
    matriz.visitado[bloco.posicao.x][bloco.posicao.y] = 'X';
    //Se o bloco actual estiver nos limites do labirinto e não for uma parede
    if(estaDentroDosLimites(bloco.posicao.x, bloco.posicao.y, matriz.tamanho) &&
        eSaidaOuCaminho(matriz, bloco.posicao.x, bloco.posicao.y))
    {
        Bloco temp;

        //Move para a esquerda, se o bloco à esquerda não for uma parede & ainda
        //não tiver sido visitado
        if(eSaidaOuCaminho(matriz, bloco.posicao.x,bloco.posicao.y+1)
                           && matriz.visitado[bloco.posicao.x][bloco.posicao.y +1] != 'X')
        {
            fila = criarFila();
            temp = matriz.matriz[bloco.posicao.x][bloco.posicao.y +1];
            //Adiciona o bloco á esquerda à fila
            enfilerar(fila, temp);
            //Executa a função tendo o bloco à esquerda com ponto de partida
            calcularCaminhosAteASaida(caminhos, matriz, caminhoCurto,
                                      caminhoPercorrido +1, fila, array, indiceDoCaminhoMaisCurto);
        }

        //Move para a Direita, se o bloco à Direita não for uma parede & ainda
        //não tiver sido visitado
        if(eSaidaOuCaminho(matriz, bloco.posicao.x, bloco.posicao.y -1)
                           && matriz.visitado[bloco.posicao.x][bloco.posicao.y -1] != 'X')
        {
            fila = criarFila();
            temp = matriz.matriz[bloco.posicao.x][bloco.posicao.y -1];
            //Adiciona o bloco á Direita à fila
            enfilerar(fila, temp);
            //Executa a função tendo o bloco à Direita com ponto de partida
            calcularCaminhosAteASaida(caminhos, matriz, caminhoCurto,
                                      caminhoPercorrido +1, fila, array, indiceDoCaminhoMaisCurto);
        }

        //Move para de baixo, se o bloco de baixo não for uma parede & ainda
        //não tiver sido visitado
        if(eSaidaOuCaminho(matriz, bloco.posicao.x +1, bloco.posicao.y)
                           && matriz.visitado[bloco.posicao.x +1][bloco.posicao.y] != 'X')
        {
            fila = criarFila();
            temp = matriz.matriz[bloco.posicao.x +1][bloco.posicao.y];
            //Adiciona o bloco de baixo à fila
            enfilerar(fila, temp);
            //Executa a função tendo o bloco à Direita com ponto de partida
            calcularCaminhosAteASaida(caminhos, matriz, caminhoCurto,
                                      caminhoPercorrido +1, fila, array, indiceDoCaminhoMaisCurto);
        }

        //Move para de cima, se o bloco de cima não for uma parede & ainda
        //não tiver sido visitado
        if(eSaidaOuCaminho(matriz, bloco.posicao.x-1, bloco.posicao.y) &&
                           matriz.visitado[bloco.posicao.x -1][bloco.posicao.y] != 'X')
        {
            fila = criarFila();
            temp = matriz.matriz[bloco.posicao.x -1][bloco.posicao.y];
            //Adiciona o bloco de cima à fila
            enfilerar(fila, temp);
            //Executa a função tendo o bloco à cima com ponto de partida
            calcularCaminhosAteASaida(caminhos, matriz, caminhoCurto,
                                      caminhoPercorrido +1, fila, array, indiceDoCaminhoMaisCurto);
        }
    }

    //Se o caminho não leva a saida, desmarca recursivamente os caminhos
    //até os ultimo caminho que contem uma ou mais direcções não visitadas
    //(Caracteristica do algoritimo BACKTRACK)
    matriz.visitado[bloco.posicao.x][bloco.posicao.y] = ' ';
}

int estaDentroDosLimites(int x, int y, Ponto tamanho)
{
    if(x < 0 || y < 0 || x >= tamanho.x || y >= tamanho.y)
        return 0;
    return 1;
}

void apresentarMatriz(MatrizLabirinto *matriz) {
    int i, j;

    for(i = 0; i< (*matriz).tamanho.x; i++)
    {
    	for (j = 0; j < (62)/2; ++j) 
                printf(" ");
        for (j = 0; j < (*matriz).tamanho.y; ++j)
        {
            if((*matriz).visitado[i][j] == 'X')
            {
                alterarCorDoTextoConsola(VERMELHO);
                if(!matriz->contemMenorCaminho)
                    alterarCorDoTextoConsola(VERDE);
                if((i == matriz->saida.x-1 && j == matriz->saida.y-2))
                	alterarCorDoTextoConsola(VERDE);
            }
            else
            {
                alterarCorDoTextoConsola(CINZA);
            }
            printf("%c", (*matriz).visitado[i][j]);
        }
        printf("\n");
    }

    printf("\n\n");
}

Array *criarArray()
{
    Array *array = (Array *)malloc(sizeof(Array));
    array->tamanho = 3;
    array->items = 0;
    array->vector = (MatrizLabirinto *)malloc(array->tamanho*sizeof(MatrizLabirinto));
    return array;
}

void inserirNaArray(Array *array, int indice, MatrizLabirinto matrizLabirinto)
{
    int i, j;
    MatrizLabirinto matriz;
    matriz.tamanho = matrizLabirinto.tamanho;
    matriz.matriz = malloc(matriz.tamanho.x * sizeof(Bloco*));
    for (i = 0; i < matriz.tamanho.x; i++) {
        matriz.matriz[i] = malloc(matriz.tamanho.y * sizeof(Bloco));
    }

    matriz.visitado = malloc(matriz.tamanho.x * sizeof(int*));
    for (i = 0; i < matriz.tamanho.x; i++) {
        matriz.visitado[i] = malloc(matriz.tamanho.y * sizeof(int));
    }

    for (i = 0; i < matriz.tamanho.x; ++i)
    {
        for (j = 0; j < matriz.tamanho.y; j++)
        {
            matriz.visitado[i][j] = matrizLabirinto.visitado[i][j];
        }
    }

    if(indice >= 0 && indice <= array->items)
    {
        for(i = array->items; i > indice; i--)
        {
            array->vector[i] = array->vector[i-1];
        }
        array->vector[indice] = matriz;
        array->items++;
    }
}

int eSaidaOuCaminho(MatrizLabirinto matriz, int x, int y)
{
    if(!estaDentroDosLimites(x,y,matriz.tamanho))
        return 0;

    return matriz.matriz[x][y].valor==' ' || (x == matriz.saida.x-1 && y == matriz.saida.y-1);
}
