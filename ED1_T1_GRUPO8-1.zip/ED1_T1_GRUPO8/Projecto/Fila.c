//
// Implementação do TAD FILA (FIFO)
//

#include <stdio.h>
#include <stdlib.h>
#include "Fila.h"

Fila *criarFila()
{
    Fila *fila;
    NoDaLista *lista;

    fila = malloc(sizeof(Fila));
    if(!fila)
        return NULL;

    lista = malloc(sizeof(NoDaLista));

    fila->inicio = fila->fim = NULL;
    fila->tamanho = 0;
    return fila;
}

int aFilaEstaVazia(Fila *fila)
{
    //Se a condição for verdadeira retorna 1 caso não retorna 0
    return(fila->inicio == NULL);
}

void enfilerar(Fila *fila, Bloco valor)
{
    NoDaLista *novoNoDaLista;
    novoNoDaLista = malloc(sizeof(NoDaLista));

    if(!novoNoDaLista)
    {
        printf("Erro de memoria!\n");
        return;
    }

    novoNoDaLista->valor = valor;
    novoNoDaLista->proximo = NULL;

    if(fila->fim)
        fila->fim->proximo = novoNoDaLista;
    fila->fim = novoNoDaLista;

    if(!fila->inicio)
        fila->inicio = fila->fim;
    fila->tamanho++;

}

Bloco desenfilerar(Fila *fila)
{
    Bloco valor;
    NoDaLista *temp;

    if(aFilaEstaVazia(fila))
    {
        printf("Lista Vazia	\n");
        return valor;
    }
    else
    {
        temp = fila->inicio;
        valor = fila->inicio->valor;
        fila->inicio = fila->inicio->proximo;
        free(temp);
        fila->tamanho--;
        if(fila->tamanho == 0)
            fila->fim = NULL;
    }
    return valor;
}


