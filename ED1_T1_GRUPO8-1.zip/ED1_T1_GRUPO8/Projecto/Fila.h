//
// Created by Trindade on 2/7/2021.
//

#ifndef SILVIA_FILA_H
#define SILVIA_FILA_H

#endif //SILVIA_FILA_H

#include<stdlib.h>

typedef struct Ponto
{
    int x,y;
}Ponto;

typedef struct Bloco
{
    char valor;
    Ponto posicao;
    int foiVisitado;
}Bloco;


typedef struct No
{
    Bloco valor;
    struct No *proximo;
}NoDaLista;

typedef struct Fila
{
    NoDaLista *inicio;
    NoDaLista *fim;
    int tamanho;
}Fila;




Fila *criarFila();

int aFilaEstaVazia(Fila *fila);

void enfilerar(Fila *fila, Bloco bloco);

Bloco desenfilerar(Fila *fila);

