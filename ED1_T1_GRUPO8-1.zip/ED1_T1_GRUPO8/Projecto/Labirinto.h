#include "Fila.h"
#include <stdio.h>

typedef enum
{
    VERMELHO = 4,
    PURPURA = 5,
    CINZA = 8,
    VERDE = 2,
    AZUL = 1,
    AZUL_CLARO = 9,
    AQUA = 3,
    PRETO = 0,
    BRANCO = 7,
}COR;
void alterarCorDoTextoConsola(COR cor);

//Representação Bi-Dimensional do labirinto
typedef struct MatrizLabirinto
{
    //Matriz original do labirinto
    Bloco **matriz;

    //Matriz com os caminhos percorridos
    char  **visitado;
    //Variaveis para o Tamanho, Entrada e Saida do Labirinto
    Ponto tamanho, entrada, saida;

    int contemMenorCaminho;
}MatrizLabirinto;

//Declaração de uma estrutura de vectores dinamica, ou seja:
//o vector mantem conta da quantidade de itens que tem armazenado
//e actuliza o seu tamanho ao se introduzir um item quando o vector
//já está cheio
//Vai ser usado para personalizar a apresentação dos caminhos validos até a saida
typedef struct Array
{
    MatrizLabirinto *vector;
    int tamanho;
    int items;
}Array;

//Função que cria uma struct Array
Array *criarArray();

//Função para inserir um item na struct Array
void inserirNaArray(Array *array, int indice, MatrizLabirinto matrizLabirinto);

FILE *lerFicheiro(char *nomeDoFicheiro);

MatrizLabirinto criarLabirinto();

void lerDadosInciais(MatrizLabirinto *labirinto, FILE *ficheiro);

void lerBlocosDoFicheiro(MatrizLabirinto *labirinto, FILE *ficheiro);


//Funcção para encontrar a saida com a ajuda de uma FILA
//Implementação usando os algoritimos BFS(Breadth First Search) & Backtrack
//Backtrack para tirar proveito da recursividade e encontrar todos caminhos possiveis
//BFS, porque por padrão utiliza filas e arvores para encontrar o caminho mais proximo
void calcularCaminhosAteASaida(int *caminhos, MatrizLabirinto matriz,
                               int *caminhoCurto, int caminhoPercorrido,
                               Fila *fila, Array *array, int *indiceDoCaminhoMaisCurto);

void prepararDados(MatrizLabirinto matriz, Array *caminhosEncontrados, int *posicaoDoMenorCaminho, int *passos);

int eSaidaOuCaminho(MatrizLabirinto matriz, int x, int y);

void apresentarMatriz(MatrizLabirinto *matriz);

MatrizLabirinto allocarMatriz(MatrizLabirinto *matriz);

int estaDentroDosLimites(int x, int y, Ponto tamanho);
