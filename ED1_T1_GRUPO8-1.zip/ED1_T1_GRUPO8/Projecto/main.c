#include <stdio.h>
#include <stdlib.h>
#include "InterfaceDeUsuario.h"


int main()
{
    SMALL_RECT windowSize = {0 , 0 , 77 , 100}; //change the values
    SetConsoleWindowInfo(GetStdHandle(STD_OUTPUT_HANDLE), TRUE, &windowSize);

    

//    prepararDados(matrizLabirinto);

    iniciarInterface();

    printf("\n\n");




    mostraCursor(0);
    system("pause > null");
	
}


